undertow-hello-world-server
===========================

The smallest http://undertow.io server you can write. The example on their front page is borked, so here's a project you can download and run with:

    gradle run

And then visit http://127.1:8080/
